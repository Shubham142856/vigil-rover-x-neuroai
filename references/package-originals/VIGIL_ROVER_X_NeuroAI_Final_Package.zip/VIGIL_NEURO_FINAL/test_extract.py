import tempfile, unittest, csv
from pathlib import Path
from extract_graph import extract
class TestExtract(unittest.TestCase):
    def test_directed_aggregation(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); (p/'ids').write_text('100000000000000001\n2\n3\n'); (p/'c.csv').write_text('pre,post,n\n100000000000000001,2,2\n100000000000000001,2,3\n2,100000000000000001,1\n2,9,99\n')
            m=extract(p/'ids',p/'c.csv',p/'out','pre','post','n',5,'synthetic')
            self.assertEqual(m['retained_edges'],1); self.assertEqual(m['isolated_nodes'],1)
            with (p/'out/edges.csv').open() as f: self.assertEqual(list(csv.DictReader(f))[0]['synapse_count'],'5')
    def test_empty_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d); (p/'ids').write_text('1\n2\n'); (p/'c.csv').write_text('pre,post,n\n1,9,7\n')
            with self.assertRaises(ValueError): extract(p/'ids',p/'c.csv',p/'out','pre','post','n',1,'synthetic')
if __name__=='__main__': unittest.main()
