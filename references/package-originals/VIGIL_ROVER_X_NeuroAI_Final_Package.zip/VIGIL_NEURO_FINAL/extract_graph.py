"""Extract directed induced graph from reviewed IDs and a local connection CSV/CSV.GZ.
No network access, no inferred cell types, no sign inference. IDs remain strings.
"""
import argparse, csv, gzip, json, hashlib
from collections import defaultdict
from pathlib import Path

def op(p):
    return gzip.open(p,'rt',newline='',encoding='utf-8-sig') if str(p).endswith('.gz') else open(p,newline='',encoding='utf-8-sig')
def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1048576),b''): h.update(b)
    return h.hexdigest()
def extract(ids, connections, out, pre, post, count, minimum, version):
    selected={s.strip() for s in Path(ids).read_text().splitlines() if s.strip()}
    if not selected or any(not x.isdigit() for x in selected): raise ValueError('Supply reviewed numeric IDs, one per line')
    pairs=defaultdict(int); total=0
    with op(connections) as f:
        reader=csv.DictReader(f)
        if not {pre,post,count}.issubset(reader.fieldnames or []): raise ValueError(f'Column mismatch: {reader.fieldnames}')
        for row in reader:
            a,b=row[pre],row[post]
            if a in selected and b in selected:
                n=int(row[count]);
                if n<0: raise ValueError('Negative synapse count')
                pairs[a,b]+=n; total+=1
    edges=[(a,b,n) for (a,b),n in sorted(pairs.items()) if n>=minimum]
    if not edges: raise ValueError('No retained edges; verify version, IDs and threshold')
    out=Path(out); out.mkdir(parents=True,exist_ok=True)
    with (out/'edges.csv').open('w',newline='') as f:
        w=csv.writer(f); w.writerow(['pre_id','post_id','synapse_count']); w.writerows(edges)
    (out/'nodes.txt').write_text('\n'.join(sorted(selected))+'\n')
    m=dict(version=version,connection_sha256=digest(connections),ids_sha256=digest(ids),selected_nodes=len(selected),retained_edges=len(edges),source_rows=total,min_synapses=minimum,isolated_nodes=len(selected-{x for a,b,n in edges for x in (a,b)}),scope='induced directed graph; signs not inferred')
    (out/'manifest.json').write_text(json.dumps(m,indent=2)); return m
if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__)
    for k in ['ids','connections','out','pre','post','count','version']: p.add_argument('--'+k,required=True)
    p.add_argument('--minimum',type=int,default=1)
    a=p.parse_args(); print(json.dumps(extract(**vars(a)),indent=2))
