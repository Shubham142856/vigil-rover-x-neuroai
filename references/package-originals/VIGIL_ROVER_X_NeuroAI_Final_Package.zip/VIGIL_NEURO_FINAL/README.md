# Start here: VIGIL-ROVER X NeuroAI
Read `NEURO_RESEARCH_PLAN.md` first. It supersedes the previous engineering appendix wherever the two differ. `Research_Resources.csv` is a curated link index, not a bundle of downloaded datasets or papers. The actual final 3D simulator and neural models are not implemented in this package.

## First acquisition task
1. Open https://codex.flywire.ai/api/download?dataset=fafb and sign in if necessary. Select FAFB v783; download consolidated cell types, Princeton connections and neuron/NT metadata. Save license and version evidence. Use the official FAQ notebook for programmatic downloads; never commit tokens.
2. Inspect annotation columns and exact types for LC4, LPLC2, DNp01/GF, E-PG/P-EN/P-EG/Delta7 (aliases vary). Review selected IDs against published diagrams; save separate `ids_escape.txt`, `ids_compass.txt`. No guessed root IDs. Check annotation and connection release match.
3. Inspect connection header; use exact column names. Example only, assuming these names exist:
```
python extract_graph.py --ids ids_escape.txt --connections connections.csv.gz --pre pre_root_id --post post_root_id --count syn_count --minimum 5 --version FAFB-v783 --out escape_graph
```
4. Check manifest and edges, compare threshold 1 vs 5. Script aggregates directed counts only; it does not infer transmitter signs or identify cell types. Validate graph coverage with Codex and literature before modeling.
5. Run `python -m unittest -v test_extract` (two synthetic tests passed in the preparation environment). Then reproduce published looming responses before training.

## Package contents
- NEURO_RESEARCH_PLAN.md: controlling implementation and research specification.
- Research_Resources.csv: verified discovery links and roles; inspect individual licenses.
- extract_graph.py / test_extract.py: schema-explicit starting utility, standard library only.
- Previous_Engineering_Appendix.md: older general software details, not authoritative for biological method.
- VIGIL_ROVER_X_NeuroAI_Plan.pdf: readable version of the controlling plan plus source links.
