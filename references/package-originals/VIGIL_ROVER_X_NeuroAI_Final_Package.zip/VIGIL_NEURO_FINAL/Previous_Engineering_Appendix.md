# VIGIL-ROVER X

**Looming-Guided Collision Avoidance and Active Blind-Spot Recovery Under Uncertain Perception**

**FINAL SOFTWARE-ONLY RESEARCH & BUILD BLUEPRINT — 25 November 2026**

**Project status:** specification and staged build plan, not an implemented VIGIL-ROVER X system. Existing VIGIL-ROVER SIM remains a runnable but limited 2D baseline.  
**Novelty threshold:** aim for **>7.5/10 only after independent literature comparison and successful, distinct algorithmic evidence**. A proposed feature count does not establish novelty.  
**Deployment scope:** CPU-first development with Kaggle GPU training; no physical hardware required.  
**Engineering boundary:** simulator outcomes do not constitute real-world safety certification.

---

## 1. Executive decision

Build one software research platform with a single authoritative **Python/PyBullet** simulation and a separate **React/TypeScript/Three.js** visualization. Do not run conflicting physics engines in the browser and backend. Begin with the source report's fly-inspired visual looming, left/right independent tactile whiskers, and four-state GF-Lite controller. Extend the system to explicitly distinguish **visibility**, **sensor integrity**, **collision threat**, **uncertainty**, and **recoverability of information**. Provide a conservative safety layer for action selection. Use **PyTorch on Kaggle** for learning, not for the primary rigid-body physics.

**Non-negotiable demonstrations:** (1) reliable looming warnings; (2) meaningful closed-loop collision avoidance; (3) blind-spot / occlusion uncertainty tracking; (4) safe active view-recovery or abstention; (5) independent tactile reflex on vision failure; (6) multi-controller statistical comparison; and (7) a responsive 3D user-facing simulator.

**Proposed scientific question:** Can a compact agent, from actual camera images and short action/observation history, determine when safe information-gathering is possible under unknown combinations of occlusion and camera faults, and improve collision-free goal progress without masking its blind spots?

## 2. Source-lineage and mandatory retained concepts

The original 14-page VIGIL-ROVER build-ready report (18 November 2026) specifies ESP32-CAM visual looming, independent left/right mechanical feelers, GF-Lite fusion, packet freshness, CLEAR/PRE-ALERT/REFLEX/DEGRADED states, and scientific comparison against contact-only, vision-only, simple fusion and gated variants. The software-only project blueprint expands these into a browser-facing 3D product with experiment management, fault injection, and analytics. The current software package implements an elementary 2D synthetic camera and robot simulation with eight controllers and eleven scripted scenarios. **This proposal retains the experimental purpose, not the original hardware procurement plan.**

Mapping: ESP32-CAM → virtual time-stamped RGB camera; Nano → independent reflex/motor control scheduler; feeler switches → left/right collision geometry; L298N + motors → velocity/acceleration limited differential-drive plant; GF-Lite → testable controller baseline; serial watchdog → virtual packet/network faults; physical trial logs → reproducible experiment records.

## 3. Current simulator audit and release blockers

Known code-level limitations warrant fixing before sophisticated ML:

| ID | Confirmed issue / limitation | Consequence | Corrective acceptance test |
|---|---|---|---|
| F01 | Image reliability includes obstacle-expansion persistence | Healthy empty scene can be falsely classified as camera failure | Clear well-exposed frames maintain healthy sensor status despite zero detections |
| F02 | Hazard labels sometimes depend on scenario name | A stationary obstacle in a rover collision path can be mislabeled safe | Oracle labels derive from geometry and counterfactual rollout, not scenario string |
| F03 | 2D circular overlaps without rigid contact resolution | Robot may penetrate obstacles; collision-frame counts overstate distinct events | Impulse/contact resolution and independent collision-event counts verified |
| F04 | Frame timestamp and packet-arrival semantics are insufficiently separated | Delayed/frozen streams may be misdiagnosed | Test age-of-image, transport delay, duplicate sequence and missing packet separately |
| F05 | Browser and Python implementations are different simulation engines | A visually convincing browser demo may not reproduce Python results | Browser reads authoritative physics state or plays recorded traces |
| F06 | Only seven passing unit tests and limited seed-based evaluation | No evidence of broad robustness | Add geometry, sensor, state-machine, deterministic-replay and OOD behavioral tests |
| F07 | Visual thresholding weakly calibrated; existing replay often alerts infrequently | Missed hazards / false confidence possible | Establish event-level recall, warning lead time and false-alert metrics |
| F08 | Fixed reverse/turn reflex does not check nearby swept space | A reflex can cause a secondary collision | Confirm tactile override, safe braking, and reverse only when escape region is verified |

**First release gate:** F01–F05 and relevant tests must be fixed before any neural-network result enters the project's scientific claims.

## 4. Literature and novelty boundary

Verified neighboring work already includes: (i) Zhao et al. (2023), a Drosophila LPLC2/GF-inspired model for virtual collision avoidance; (ii) 2026 motion-contour contrast-robust looming; (iii) OA-MPC (2025), occlusion-aware planning for unseen dynamic obstacles; (iv) Ni et al. (2026), safety-constrained active model discrimination and diagnosis via differentiable reachability; (v) VISTA-CBF+ELR (August 2026), visibility-aware navigation and bounded occlusion replanning; and (vi) recent unified risk-mapping and uncertainty-aware navigation. Full links appear in Section 18.

**Known and not claimable as original:** image expansion/TTC, fly-inspired looming, CBF/MPC safety filtering, generic uncertainty heads, active viewpoint selection, simple GRUs, and combining camera and tactile sensors. Even a highly polished 3D application does not establish algorithmic novelty.

**Candidate research mechanism (not verified novel):** *COVER-L* — **Counterfactual Observability and Risk-Gated Recovery for Looming navigation**. It explicitly asks whether a prospective small action would *disambiguate* competing explanations for an uncertain image **before** applying it. It uses a learned posterior over hidden hazard and sensor hypotheses, an occlusion-aware unknown-space representation, a counterfactual risk model, and an action-feasibility gate. Unlike naive confidence-based stopping, it can seek evidence; unlike naive active vision, it must reject actions whose possible outcomes cross the conservative braking/clearance envelope. This is a working research hypothesis; the underlying parts overlap prior art.

**Novelty gate >7.5/10 requires all three:** A clearly reproduced prior-art failure; a distinguishable technical mechanism or defensible new theoretical result beyond a known combination; and independent gains that survive strong method-specific baselines, matched computing budget, OOD splits and ablations. If any fails, report the actual novelty level and revise scope.

## 5. Physical and computational world model

Use a realistic small 2-wheel differential-drive rover represented in a 3D warehouse or corridor, with planar driving on a rigid floor. The simulator contains chassis collisions, wheel dynamics, commanded torque/velocity, acceleration limits, turning radius, robot footprint, friction, collision impulses, moving obstacles, walls, furniture and variable lighting. World geometry and dynamics are the evaluator's ground truth, **not an observation automatically accessible to the controller**.

Start with explicit, configurable values (engineering defaults, not measured hardware specifications): rover footprint ~0.20 × 0.16 m, wheelbase ~0.14 m, speed up to 0.35 m/s, conservative braking deceleration 0.4–0.8 m/s², camera horizontal FOV ~80°, 128×96 RGB at 10 Hz, controller 20 Hz, rigid-body physics at 120 Hz, simulation clock deterministic, with values adjustable by config. The sensor observation contains only data available under the chosen sensor budget, including previous wheel commands and a low-cost motion estimate when enabled; no perfect pose, true depth or oracle obstacle coordinates.

**Timing contract:** fixed-step physics; camera captures use image capture timestamps; observation delivery uses distinct receipt timestamps; controller sees only delivered frames; tactile interrupt processes independently; render and ML training do not alter simulation stepping. Record all scheduling events and random generators.

**Safety model limitation:** under an unobserved obstacle capable of suddenly moving into the robot, unconditional collision-free guarantees are generally unavailable. All proposed filters are conditional on stated motion bounds and sensor assumptions. Stops may be safest but cannot guarantee avoidance of an external moving agent hitting the stopped rover.

## 6. Camera, looming and biological inspiration

Implement a real simulator camera, not a direct reading of obstacle positions masquerading as vision. Store RGB frames, intrinsics, pose metadata for evaluation, capture/arrival times, sequence IDs and optional detector overlays. Start classical vision: intensity normalization, motion-contour extraction, feature/region tracking, apparent angular expansion and time-to-contact proxy. Add a shallow LPLC2-inspired radial expansion channel and a GF-like trigger as a separately evaluated biological baseline. This is an engineered analogue, not a reproduced fly connectome.

For a tracked object with apparent linear image size `s(t)`, a common approximate expansion proxy is `rho=(s_t-s_(t-1))/(max(s_(t-1),eps)*dt)` and `tau≈s/(ds/dt)` if growth is positive. These values are **not** definitive collision times. Require tracking consistency, angular bearing and estimated ego-motion. Distinguish approaching objects on a passing trajectory from true collision courses; an expanding object need not hit the rover. Use saved previous controls and image flow for ego-motion compensation; optional simulated IMU/odometry must be labeled as an extension/ablation beyond the original camera+whisker budget.

**Output contract:** region candidate tracks, bearing, expansion, radial flow coherence, estimated TTC with validity mask, motion/ego-consistency score, visual threat estimate and timestamps. False looming from yaw, light ramps, tracker-ID switches or near-misses must be included in the test suite.

## 7. Blind spot, occlusion and sensor-failure intelligence

Four observational failure classes must remain distinct: (a) object outside field of view; (b) occlusion by visible geometry; (c) image degradation causing uncertain detection; and (d) stale/frozen/failed camera service. A fifth case is an actual visible collision threat. The model must be allowed to output `unknown` when evidence cannot distinguish alternatives.

Implement a **visibility-memory layer** with per-sector state: `visible_obstacle`, `observed_free_with_assumptions`, `occluded`, `outside_FOV`, and `unknown_or_stale`. These are *belief labels*, not ground truth. Camera-pose and estimated object tracks update the short-term map; stale observations decay toward unknown. Monocular RGB cannot certify 3D free space, so free-space claims must document a ground-plane/homography assumption or learned geometry with calibrated uncertainty. Keep an optional oracle visibility raster for evaluation only; do not expose hidden depth or true occluded obstacle masks to the controller.

Design safe scan primitives as **brake and inspect**, **stationary left yaw**, **stationary right yaw**, **small reverse only if rear/swept area previously observed**, and **resume or stop**. A body-yaw scan consumes time, changes visual flow and can sweep the robot into nearby objects: check swept geometry under conservative occupancy before attempting. A camera pan is optional and must be presented as a future hardware extension; default uses body rotation to respect original design.

**Essential impossibility test:** generate two simulated worlds with identical entire observable camera/tactile histories but different completely occluded hazards. No controller can correctly identify the hidden state from the same observations. It should not hallucinate knowledge; it should represent uncertainty and choose an action under clearly stated assumptions.

## 8. Separate sensor integrity, threat and epistemic uncertainty

Use three separate estimates from current and historical observations:

`q_t = P(sensor usable | frame statistics, timestamps, temporal image consistency)`

`r_t(a) = P(collision within horizon H | observation history, candidate action a)`

`u_t(a) = uncertainty/confidence interval of predicted risk under action a`

A well-lit empty frame can have **high camera health and low hazard**. A clear-looking but completely occluded corridor may have **high camera health and high or uncertain hidden hazard**. An overexposed image may have low camera health but is not automatically proof of collision. These differences must be reflected in separate training labels, network heads, calibrators and monitoring plots.

Initial sensor-health features: frame freshness, frozen-frame hash, saturation ratio, exposure/contrast changes, blur, image continuity, telemetry faults and camera output validity. An ambiguous low-texture wall alone must not be diagnosed as physical camera failure without corroboration.

## 9. Proposed algorithm: COVER-L

Maintain a compact belief state `b_t` about hazard trajectories, visible/unknown local space and sensor operating condition. Candidate actions are bounded motion primitives (continue slowly, brake, stop, left/right stationary scan, cautious turn, safe reverse if possible). A temporal encoder predicts the distribution of collision outcomes and future information for every candidate action. An uncertainty calibrator predicts or bounds model error for in-distribution and tested shifted cases. A conservative filter rejects actions whose swept region or stopping envelope is not sufficiently supported.

**Candidate novelty to investigate:** an *actionable observability margin* that evaluates how much each safe action could reduce uncertainty over collision-critical hypotheses. For safe candidate action `a`, estimate

`Delta_info(a) = U(b_t) - E[U(b_(t+1)) | b_t, a]`

where `U` is a specified risk-relevant ambiguity functional, not image entropy alone. Combine this with expected task progress, actuation cost and conservative risk. A feasible informative maneuver is chosen only when its expected information gain exceeds a validation-chosen cost threshold and its conservative collision-risk estimate satisfies a separately defined bound. If the safe-information set is empty or model uncertainty is unbounded, **abstain and stop**. These principles are closely related to active diagnosis and risk-aware planning; the empirical novelty must come from the *specific new estimator/criterion and its behavior under observational ambiguity*.

**Controller hierarchy (priority first):**

1. Emergency stop or confirmed bilateral contact → stop and log.
2. Confirmed left/right contact → brake immediately; reverse/turn away only if a checked exit maneuver exists; otherwise hold stop.
3. Imminent visually supported collision → brake/avoid under stopping-distance and path-clearance checks.
4. Visual invalid/frozen → conservative stop; never mistake absent frames for free space.
5. Uncertain blind spot / occlusion → check safe scanning feasibility; gather information if worthwhile, otherwise stop.
6. Low risk with useful visibility → move toward goal at bounded speed.

**Physics-aware conservative rule:** account for reaction/processing delay `T_d`, measured worst-case braking `a_min`, and clearance margin `m` using `d_stop >= v*T_d + v^2/(2*a_min) + m`. Under unknown obstacles, this is an engineering stopping-distance bound *for known geometry and assumed dynamics*, not a proof that free space exists.

## 10. ML architecture, labels and training

**Stage A (non-neural):** GF-Lite with corrected health gating; optical-flow/looming baseline; static risk thresholds; logistic regression and gradient-boosted trees.

**Stage B (GPU):** small temporal network with optional compact CNN stem and GRU/temporal convolution backbone. Suggested pilot: RGB 96×72 or derived features, window length 8–16 time steps, hidden dimension 64, 1–2 recurrent layers, causal inference only. Train separate heads for `sensor health`, `action-conditional collision probability`, `uncertainty`, and optional `TTC bins` / `recoverability`. Train in PyTorch on one available Kaggle GPU; use the second T4 only if independent parallel trials measurably improve throughput.

**Label generation must be physically correct:** from a saved simulator state, clone/restore *both physics state and every application RNG/scheduler state*, then evaluate a fixed candidate macro-action for `H=1–2s` under identical obstacle scripts. Label `collision_under_action`, `minimum_clearance`, and `future sensor informativeness`. Store the action sequence and fallback policy precisely. Do not assign collision labels from scenario names or from a different policy's realized trajectory.

**Loss for pilot:** `L = λ_h BCE(sensor_health) + λ_c BCE(collision_by_action) + λ_t Huber(TTC_valid) + λ_u calibration/uncertainty_objective`. Optimize coefficients on validation only, with class balance and probability calibration. Information-gain head is optional until counterfactual rollouts are validated. Report reliability diagrams, Brier score, calibration drift, AUROC/PR-AUC, and false negative rates, not accuracy alone.

**Stage C (optional):** short-horizon model-predictive control using model heads. Recurrent PPO can be a controlled additional baseline, not a prerequisite or automatic source of novelty.

**Important leakage prevention:** oracle state, true depth, object IDs, exact fault class and future collision labels are stored in the evaluator sidecar and are inaccessible through `env.step(...).observation`; include a unit test that enumerates observation keys and checks this rule.

## 11. Experimental world and scenario collection

Start with procedural PyBullet worlds and controlled camera visibility. Aim for these scenario families:

| Family | Variables | Required adversarial contrast |
|---|---|---|
| Looming | object size, speed, distance, bearing, texture | expanding but safe near-miss vs true collision course |
| Robot motion | yaw, wheel asymmetry, acceleration, vibration | apparent expansion induced by ego-motion |
| Static occlusions | shelf, column, doorway, blind corner | hidden object vs empty behind occluder |
| Dynamic occlusions | moving cart, moving target, cross traffic | newly emerging hazard from behind occluder |
| FOV blind spots | ± lateral objects, rear traffic | no precontact evidence outside camera FOV |
| Illumination | night, shadows, glare, low contrast | camera usable but target hard to detect vs actual failure |
| Sensor faults | stale, freeze, dropped, delayed frames, lens cover | empty scene vs dead camera evidence |
| Reflex faults | noisy or stuck whisker, dual contact | correct prioritization under visual blackout |
| Combined OOD | multiple previously unseen perturbations | generalization without training-scene repetition |

**Pilot scale:** 200–500 manually inspected episodes (first correctness gate). **First training set:** ~3,000–10,000 procedurally diverse episodes if CPU rendering budget permits. **Final evaluation:** at least hundreds of independent held-out episodes per scenario family with matched seeds across controllers; increase using confidence-interval width or power analysis. Numbers are planning targets, not guarantees of adequate statistical power. Use feature-only dataset generation first if RGB rendering is too expensive.

Record `scenario_family`, `world_id`, `seed`, geometry hash, camera intrinsics, scheduler timestamps, action, observation IDs, visible/occluded/unknown masks, privileged oracle labels in a separate file, reward, collision-event IDs, minimum clearance, goal progress, model version and controller decisions. Store compressed images only where necessary; Parquet/CSV/JSON for features, metadata and summaries. Keep source seed and code commit for every result.

**Data partitions:** split by *world geometry*, obstacle scripts, materials, fault compositions and optionally environmental assets. Reserve entirely unseen combination families for final test. Train/validation/test from the same generator alone does not establish real-world generalization; real datasets below evaluate image robustness only unless comparable action/geometry labels exist.

## 12. External datasets and resource collection

1. **TartanGround (PRIMARY external perception resource)** — https://tartanair.org/tartanground/ — expressly includes differential-drive robot trajectories, front RGB, depth, semantic maps, IMU and multiple camera directions; provides a useful dataset for blind-spot/visible-vs-unknown perception research. Select small **front-camera differential-drive** subsets, **not** all cameras (full corpus is about 16 TB). The official source states CC BY 4.0 for data and MIT for toolkit. A small derived demonstration subset at https://huggingface.co/datasets/Voxel51/TartanGround is an optional starting point. IMPORTANT: native data has extra cameras/depth; these are teacher/oracle data only, never privileges available to our single-front-camera policy.
2. **TartanAir V2** — https://tartanair.org/ — synthetic richly textured indoor/outdoor imagery with depth, flow, segmentation and varied camera models; useful for visual representation pretraining/domain shifts, not a direct benchmark of our rover's closed-loop collision outcomes. Website states CC BY 4.0 dataset and MIT toolkit. Select a few scenes.
3. **OpenLORIS-Scene** — https://lifelong-robotic-vision.github.io/dataset/scene — real robot camera/IMU/odometry under changing scenes and lighting; useful for image-robustness and self-motion tests, not direct collision-outcome supervision. Download page states CC BY-ND 4.0 restrictions on redistributed derivatives; verify precise terms.
4. **UT Campus Object Dataset (CODa)** — https://doi.org/10.18738/T8/BBOQMV — real mobile-robot egocentric RGB/LiDAR/IMU with object labels, for qualitative OOD object/occlusion perception studies; verify rights before redistribution. Do not confuse with the road corner-case CODA dataset.
5. **Published LPLC2/GF baseline code** — https://github.com/zhaojunyu01/EMD-LPLC2-GF-model — inspect/cite original paper; reproduce selected model behavior before claiming biological improvements; verify source code license before reuse.
6. **Safe active model discrimination paper and code** — https://arxiv.org/abs/2606.19590 and https://github.com/gtfactsLab/Ni_RAL2026 — methodological comparator; exact assumptions differ from a partially observable camera setting.
7. **OA-MPC reference** — https://ieeexplore.ieee.org/document/10819000 — benchmark concept for occluded agents; reproduce a methodologically faithful baseline if authors' code is unavailable.

No public dataset by itself provides verified labels for all our counterfactual camera-fault plus occlusion plus action outcomes. Our *procedural simulator and oracle labeling protocol* are therefore the main dataset infrastructure contribution.

## 13. Technology selection and hardware/compute feasibility

| Component | Exact choice | Reason | Priority |
|---|---|---|---|
| Runtime | Python 3.11 | packaging and broad ML support | Required |
| Physics | PyBullet DIRECT / URDF | CPU headless physics, collisions, rendered camera | Required |
| Image processing | OpenCV + NumPy | flow, segmentation, metrics | Required |
| Environment API | Gymnasium-compatible wrapper | consistent train/eval contracts | Required |
| Learning | PyTorch | Kaggle GPU temporal models | After labels validated |
| Classical baseline | scikit-learn; optional XGBoost | competitive interpretable baselines | Required |
| Experiment tracking | JSON/Parquet; optional MLflow | reproducibility | Required minimal |
| Calibration/analysis | SciPy, pandas, Matplotlib | risk analysis, uncertainty and statistics | Required |
| UI | React + TypeScript + Three.js (via R3F) | professional browser 3D viewer | After simulator |
| Communication | FastAPI WebSocket + Pydantic schemas | stream true simulator state and sensor frames | After simulator |
| Charts | Plotly.js | progress / risk / timeline metrics | UI phase |
| Quality | pytest, Vitest, Playwright, ruff, mypy | software correctness | Required |
| Video | FFmpeg | synchronize 3D playback, sensor frame and graphs | Demo phase |
| DevOps | Git, GitHub, Docker optional | versioned development / CI | Git required |
| Cloud training | Kaggle GPU T4×2 option where available | train compact models without local GPU | Optional training acceleration |

Kaggle announced retirement of Tesla P100 after 15 September 2026; T4×2 remains an announced option (2 × 16 GB GPUs), subject to availability, account limits and quota. These are **separate GPUs**, not one combined 32 GB device. Inspect actual Kaggle accelerator options before planning a run. Standard PyBullet dynamics remain CPU-first; training PyTorch models is the principal use of the Kaggle GPU.

On an older CPU-only laptop, start at 96×72 or 128×96 camera resolution, 5–10 Hz vision, simplified geometry, one world at a time, and headless simulations. The high-quality browser presentation is a separate visualization budget. Use 3D assets with appropriate licenses; do not assume copyrighted product photos/images are usable as textures.

## 14. Authoritative runtime architecture and software interfaces

```
frontend: React / R3F / Plotly
  └── WebSocket viewer: receives server-generated pose, camera feed, events, metrics
backend: FastAPI + experiment job queue
  ├── PyBullet engine: physics, 3D contact, world ground truth
  ├── Virtual sensor scheduler: camera, whiskers, packet faults
  ├── Perception: looming, flow, image integrity
  ├── Belief estimator: health + occlusion + action risk
  ├── Controller: GF-Lite | COVER-L | baselines
  ├── Safety/reflex gate: emergency, tactile, brake/swept volume
  ├── Episode logger / counterfactual labeling / Gymnasium wrapper
  └── Research pipeline: calibration, CI, OOD benchmarking, reports
Kaggle: read versioned datasets -> train -> export model weights + config
```

**Required data contracts:**

- `Observation`: capture time, arrival time, camera frame ID/pixels or features, motor command history, whisker L/R, sensor validity metadata. Never include privileged oracle pose/depth/obstacle truth in production observation.
- `Action`: left/right wheel target velocities or bounded maneuver ID; requested vs applied commands tracked separately.
- `WorldSnapshot`: physics state, obstacle script states, clock, RNG states, sensor scheduler, network queue state, controller internal state.
- `Event`: contact begin/end, warning, pre-alert, diagnostic scan, stop, camera fault, restart, goal, terminal collision.
- `EpisodeResult`: scenario family, conditions, controller version, goal outcome, unique collision events, time, path, false stops, TTC, clearance, calibration metrics.

**Non-negotiable:** one actual physics world. The browser does not independently decide scientific collisions or synthesize separate sensor measurements for a reported experiment.

## 15. Fair benchmark and statistical methodology

Baseline ladder: B0 permanent safety stop (trivial control); B1 contact-only; B2 vision-only looming; B3 GF-Lite; B4 corrected gated GF-Lite; B5 risk-conditioned MPC without active sensing; B6 naive periodic blind-scan; B7 active information gain without safe-action filter; B8 known occlusion-aware/safe active diagnosis adaptation where implementation assumptions permit; B9 COVER-L proposal; B10 oracle-world controller (upper bound only, not deployable). Do not compare only with weak handcrafted rules.

**Open-loop perception replay** answers whether algorithms identify the same stimulus differently. **Closed-loop evaluation** answers whether their different actions actually improve robot outcomes. Keep both; never present replay success as navigation success.

Primary metrics: unique collision episodes per fixed number of starts, goal attainment, normalized progress, time-to-goal, unnecessary stops per minute/meter, minimum clearance, advance warning lead time, risk Brier score and expected calibration error, worst-fault-family performance, safe recovery success among *actually recoverable* cases, and diagnosis abstention on unidentifiable cases. Also report CPU/GPU training hours, inference latency, control deadline misses and blind-spot exposure time.

Statistical plan: pre-register primary outcome (e.g. collision-free goal completion), paired starts per method, multiple independently generated worlds, bootstrap confidence intervals by **episode/world** (not by correlated frames), multiple seeds for training and evaluation, track optimizer budget, and report all failures. Define scenario validity and metric implementation tests *before* training.

**Ablations:** remove looming, remove occlusion memory, collapse sensor health into hazard confidence, remove action-conditioned risk, remove active scan, remove scan-feasibility gate, remove tactile reflex, replace GRU by feature-only baseline, train without combined-fault augmentation. The full model must outperform a version with each critical proposed ingredient removed for a convincing mechanistic argument.

**Novelty-falsification conditions:** if corrected GF-Lite or ordinary occlusion-aware MPC matches the proposed controller, or gains vanish on unseen faults, or the safety gate never allows useful information recovery, the novelty hypothesis is not supported. Preserve these findings rather than declaring success.

## 16. Sixteen-week gated build schedule

| Weeks | Build stage | Deliverable and gate |
|---|---|---|
| 1–2 | Baseline audit + defects | F01–F05 fixed, expanded pytest suite, healthy-empty, static obstacle and stale packet tests |
| 3–4 | PyBullet world + rover | Robot URDF, differential drive, 3D contact, obstacle penetration prohibited, repeatable headless runs |
| 5–6 | RGB camera, looming and blind spots | Camera stream with timestamps, image-derived looming, visibility memory, ego-motion negative controls |
| 7 | Whisker / fault priority | Independent left/right/bilateral contact, safe reflex, freeze/drop/blur/stale injection |
| 8 | Valid data and oracle labeling | Action-conditioned collision labels validated, no oracle leakage, fixed scenario generator |
| 9–10 | Classical + temporal ML | Strong baselines trained; Kaggle GRU/CNN pilot, calibration and saved model checkpoints |
| 11–12 | COVER-L active observability | Risk and information-gain actions, feasibility gate, conservative stopping and recovery logs |
| 13 | Unseen-composition evaluation | Held-out hidden geometry and combined faults; blinded benchmark runs and failure analysis |
| 14–15 | React/Three.js research dashboard | Live 3D rover, exact camera feed, fault controls, model introspection, experiment export, demo videos |
| 16 | Ablations, review and manuscript go/no-go | Versioned code/data, reproducible tables, limits, transparent novelty assessment and finished report |

The 16-week timeline is an ambitious team plan, not a guaranteed duration. Parallelize UI work after interface contracts are stable, but avoid premature frontend investment before the physics and labeling gates pass. If the PyBullet image-generation cost is too high, train on engineered visual features first.

## 17. Detailed acceptance tests / minimum release contract

**Simulation validity:** fixed seed + fixed build reproduces world trajectories to a defined numerical tolerance; collision events occur at physical contact; no obstacle penetration beyond tolerance; moving obstacles obey logged scripts; replay includes RNG and external scheduler state.

**Looming:** high event-level recall on calibrated collision courses; low false warning on lateral/receding/rotation-only examples; track IDs persist as configured; incorrect or undefined TTC is marked invalid.

**Blind spots:** unseen region never automatically mapped free; occluded object location is not leaked to the controller; loss of stale memory increases uncertainty; two observationally indistinguishable worlds result in appropriately uncertain decisions.

**Integrity:** healthy empty frames are not camera failure; stuck-frame hashes plus timestamps diagnose intentional freezes; glare and low contrast change quality labels without deterministic fake fault attribution; recovery requires fresh evidence.

**Control:** tactile contact preempts vision at the next scheduled reflex-processing step; bilateral contact → stop; no reversing into unsensed path; scan selected only if checked swept envelope is acceptable; controller abstains when no safe information-gathering action is certified under stated assumptions.

**ML:** deterministic data lineage; no oracle leakage; calibration and PR-AUC from held-out data; model and thresholds frozen before final tests; 5+ independent training seeds for paper-level comparisons where feasible.

**Product:** editor saves/reloads world; user can choose policy and inject faults; frame/pose telemetry synchronized; export CSV/Parquet/MP4; UI labels synthetic versus real sources; no inflated live accuracy claims.

## 18. Verified bibliography and tools

1. Zhao et al., 2023, *A fly inspired solution to looming detection for collision avoidance*, iScience. https://pmc.ncbi.nlm.nih.gov/articles/PMC10073940/
2. Related public research code, EMD-LPLC2-GF-model: https://github.com/zhaojunyu01/EMD-LPLC2-GF-model
3. *Bio-Inspired Motion-Contour-Guided Visual System for Contrast-Independent Looming Perception*, 2026. https://pmc.ncbi.nlm.nih.gov/articles/PMC13204797/
4. *OA-MPC: Occlusion-Aware MPC for Guaranteed Safe Robot Navigation With Unseen Dynamic Obstacles*, IEEE TCST 2025. https://ieeexplore.ieee.org/document/10819000/
5. Ni, Ornik, Chou, Coogan, *Safe, Real-Time Active Model Discrimination and Fault Diagnosis for Nonlinear Systems via Differentiable Reachability*, IEEE RA-L 2026. https://arxiv.org/abs/2606.19590
6. Ni et al. authors' reference implementation: https://github.com/gtfactsLab/Ni_RAL2026
7. Ghaleb et al., *Feasibility-Aware Visibility-Risk Navigation for Mobile Robots in Industry 4.0*, Machines, August 2026. https://www.mdpi.com/2075-1702/14/9/980
8. *A Unified Local Risk Map for Uncertainty-Aware Mobile Robot Navigation in Cluttered and Dynamic Environments*, Sensors 2026. https://pmc.ncbi.nlm.nih.gov/articles/PMC13307091/
9. TartanGround differential-drive robot imagery and license: https://tartanair.org/tartanground/
10. TartanAir V2 dataset documentation and license: https://tartanair.org/
11. OpenLORIS-Scene real robot dataset: https://lifelong-robotic-vision.github.io/dataset/scene
12. OpenLORIS download and derivative distribution terms: https://github.com/lifelong-robotic-vision/OpenLORIS-Scene/blob/master/download.md
13. UT Campus Object Dataset (mobile-robot CODa): https://doi.org/10.18738/T8/BBOQMV
14. PyBullet official GitHub and documentation: https://github.com/bulletphysics/bullet3
15. Gymnasium custom environment interface: https://gymnasium.farama.org/introduction/create_custom_env/
16. Stable-Baselines3 Contrib RecurrentPPO reference (optional only): https://sb3-contrib.readthedocs.io/en/master/modules/ppo_recurrent.html
17. React Three Fiber documentation: https://r3f.docs.pmnd.rs/
18. React Three Rapier physics (only if standalone browser physics is later needed): https://pmndrs.github.io/react-three-rapier/
19. Kaggle P100 retirement / T4×2 announcement: https://www.kaggle.com/product-announcements/735239
20. Kaggle Notebooks: https://www.kaggle.com/docs/notebooks


## 19. Research integrity, limits and final completion standard

The primary achievement of VIGIL-ROVER X should not be a screenshot, teaser video, or arbitrary 8/10 novelty rating. It should be a **transparent research instrument** that turns images and time-stamped observations into tested collision decisions under demonstrable uncertainty, including when information cannot be safely recovered. The baseline must actually function; the learned method must beat credible baselines under appropriately hard held-out conditions; the reproducibility package must let others rerun its core claims.

The original VIGIL-ROVER project is worth preserving, especially its separate tactile reflex. The final system should keep looming collision anticipation as the main perceptual signal and treat active blind-spot recovery as the prospective research innovation—without claiming it can see through occluders, guarantee zero collisions, or solve general active perception.

**Go/no-go on >7.5 novelty:** independent side-by-side method comparison, exact citation-based claims and a reproducible new result. Until then, novelty remains *undetermined*, even if the engineering product is exceptional.
